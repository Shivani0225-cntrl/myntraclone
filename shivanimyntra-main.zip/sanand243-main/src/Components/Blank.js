import React from 'react'

function Blank() {
  return (
    <div>
      <br/><br/><br/><br/>
    </div>
  )
}

export default Blank
