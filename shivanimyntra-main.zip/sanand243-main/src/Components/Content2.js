import React from 'react'

function Content2() {
  return (
    <>
      {/* Container2 */}
      <br/>
<div className="product" id='content2'>
    <h2>BIGGEST DEALS ON TOP BRANDS</h2>
    <br/><br/><br/>

  <div className="product_container ">

     <div className='row m-4 '>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
                <img src="IMGG\myntra15.webp" alt=""/>
            </div>
            
        </div>
        <div className="item col-lg-2 col-sm-6  m-4">
            <div className="items_img">
                <img src="IMGG\myntra16.webp" alt=""/>
            </div>
            
        </div>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
                <img src="IMGG\myntra17.webp" alt=""/>
            </div>
            
        </div>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
                <img src="IMGG\myntra18.webp" alt=""/>
            </div>   
        </div>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
               <img src="IMGG\myntra19.jpg" alt=""/>
            </div>
            
        </div>
        
        </div>
       
 
    </div>
</div>
<br/><br/><br/>
    </>
  )
}

export default Content2
