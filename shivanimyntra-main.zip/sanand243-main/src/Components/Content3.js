import React from 'react'

function Content3() {
  return (
    <>
      {/* Container3 */}

<div className="product2" id='content3'>
    <h2>CATEGORIES TO BAG</h2>
    <br/><br/><br/>

  <div className="product_container ">

     <div className='row m-4 '>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
               <div class="images">
                   <img src="IMGG\myntra25.webp" alt=""/>
                   <br/>
                   <img src="IMGG\myntra26.webp" alt=""/>
               </div>
            </div>
            
        </div>
        <div className="item col-lg-2 col-sm-6  m-4">
            <div className="items_img">
               <div class="images">
                      <img src="IMGG\myntra27.webp" alt=""/>
                      <br/>
                      <img src="IMGG\myntra28.webp" alt=""/>
                  </div>
            </div>
            
        </div>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
                <div class="images">
                       <img src="IMGG\myntra29.webp" alt=""/>
                       <br/>
                       <img src="IMGG\myntra30.webp" alt=""/>
                   </div>
            </div>
            
        </div>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
                <div class="images">
                       <img src="IMGG\myntra31.webp" alt=""/>
                       <br/>
                       <img src="IMGG\myntra32.webp" alt=""/>
                 </div>
            </div>   
        </div>
        <div className="item col-lg-2 col-sm-6 m-4">
            <div className="items_img">
                    <div class="images">
                           <img src="IMGG\myntra33.webp" alt=""/>
                           <br/>
                           <img src="IMGG\myntra34.webp" alt=""/>
                       </div>
            </div>
            
        </div>
        
        </div>
       
 
    </div>
</div>
<br/><br/><br/>
    </>
  )
}

export default Content3
